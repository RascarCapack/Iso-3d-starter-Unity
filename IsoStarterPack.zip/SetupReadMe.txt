Thanks for checking the Isometric 3d starter pack for Unity URP !

SETUP:
  Drag and drop the Unity package in a new unity urp project and import everything.
For everything to work you will then need to either:
-go to "Assets" in the top bar and click on "re-import all".
-close unity, locate your project folder on your machine and delete the library folder. When you re-open the project Unity will reload the domain.

This is a collection of assets meant to kickstart your isometric 3d game in Unity.
I hope you will find it useful. I will keep adding stuff to it as time passes.

Feedbacks/request/bug reports: 
RascarCapackDev@gmail.com

Discord:
https://discord.gg/YuUyweJg
